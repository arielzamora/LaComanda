import { MesaBoardComponent } from './../componentes/mesa-board/mesa-board.component';
import { PedidosBoardComponent } from './../componentes/pedidos-board/pedidos-board.component';
import { EmpleadosBoardComponent } from './../componentes/empleados-board/empleados-board.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BienvenidaComponent } from '../componentes/bienvenida/bienvenida.component';
import { EmpleadosComponent } from '../componentes/empleados/empleados.component';
import { ClientesComponent } from '../componentes/clientes/clientes.component';
import { EmpleadosLoginComponent } from '../componentes/empleados-login/empleados-login.component';
import { EmpleadosRegistroComponent } from '../componentes/empleados-board/empleados-registro/empleados-registro.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../guards/auth.guard';
import { NologinGuard } from '../guards/nologin.guard';
import { PerfilComponent } from '../componentes/empleados-login/perfil/perfil.component';
import { EncuestaComponent } from '../componentes/clientes/encuesta/encuesta.component';
import { EmpleadosChartsComponent } from '../componentes/empleados-board/empleados-charts/empleados-charts.component';


const routes: Routes = [
  { path: '', redirectTo: '/Bienvenida', pathMatch: 'full' },
  { path: 'Bienvenida', component: BienvenidaComponent ,canActivate:[AuthGuard]},
  {
    path: 'Login', component: EmpleadosLoginComponent,canActivate:[NologinGuard]},
   {
    path:'Registro',
    component:EmpleadosRegistroComponent,
    data:{roles :['Socio'] }
  },
   {
    path: 'Empleados',
    component: EmpleadosComponent,
    canActivate: [AuthGuard],
    data: { roles: ['Socio', 'Cocinero', 'Bartender', 'Cervecero', 'Mozo'] },
    children: [
      { path: '', redirectTo: 'Pedidos', pathMatch: 'full' },
      {
        path: 'Empleados',
        component: EmpleadosBoardComponent,
        canActivate: [AuthGuard],
        data: { roles: ['Socio'] }
      },     
      {
        path: 'Estadisticas',
        component: EmpleadosChartsComponent,
        canActivate: [AuthGuard],
        data: { roles: ['Socio'] }
      },     
      {
        path: 'Perfil',
        component: PerfilComponent,
        canActivate: [AuthGuard],
        data: { roles: ['Socio', 'Cocinero', 'Bartender', 'Cervecero', 'Mozo'] }
      },
      {
        path: 'Pedidos',
        component: PedidosBoardComponent,
        canActivate: [AuthGuard],
        data: { roles: ['Socio', 'Cocinero', 'Bartender', 'Cervecero', 'Mozo'] }
      },
      {
        path: 'Mesas',
        component: MesaBoardComponent,
        canActivate: [AuthGuard],
        data: { roles: ['Socio', 'Mozo'] }
      },
      {
        path: 'Clientes/:codMesa', 
        component: ClientesComponent,
        canActivate: [AuthGuard],
        data: { roles: ['cliente'] }
      },
      {
        path: 'Encuestas', 
        component: EncuestaComponent,
        canActivate: [AuthGuard],
        data: { roles: ['cliente'] }
      }  
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ],
  declarations: [
  ]
})
export class AppRoutingModule { }
