//import { HttpBase } from './http-base.service';
import { Injectable } from '@angular/core';
import { Captcha } from '../clases/Captcha';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CaptchaService {
  //constructor(public miHttp: HttpBase) { }
  returnObs:Observable<Captcha>;
  returnPro:Promise<any>;
  constructor() { }

  public GetCaptcha(): Observable<Captcha> {
    //return this.miHttp.httpGetO<Captcha>('captcha');
    return this.returnObs;
  }

  public PostCaptcha(key: string, color: string): Promise<any> {
    const request: Object = {
      key: key,
      color: color
    };
    //return this.miHttp.httpPostP('captcha', request);
    return this.returnPro;
  }
}

