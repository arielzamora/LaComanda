import { Menu } from './../clases/Menu';
import { Injectable } from '@angular/core';
//import { HttpBase } from './http-base.service';
import { Observable } from 'rxjs';
import { map, tap, catchError, timeInterval } from 'rxjs/operators';

import {AngularFirestore,AngularFirestoreCollection,AngularFirestoreDocument}from '@angular/fire/firestore';
import { firestore } from 'firebase';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  


  private menuColeccion:AngularFirestoreCollection<Menu>;
  private menuDoc:AngularFirestoreDocument<Menu>;
  private menus:Observable<Menu[]>;
  private menu:Observable<Menu>;

  constructor(private afs:AngularFirestore) {

    this.menuColeccion=afs.collection<Menu>('Mesa');
    this.menus=this.menuColeccion.valueChanges();

  }

  public Listar(): Observable<Menu[]> {
    this.menuColeccion=this.afs.collection<Menu>('Menu');
    return this.menus=this.menuColeccion.snapshotChanges()
     .pipe(map(changes => {
       return changes.map(action => {
         const data = action.payload.doc.data() as Menu;
         data.id = action.payload.doc.id; 
         return data;
       });
     }));
  }

  public ListarPorId(idMenu:string): Observable<Menu[]> {
    this.menuColeccion=this.afs.collection<Menu>('Menu',x=>x.where("id","==",idMenu));
    return this.menus=this.menuColeccion.snapshotChanges()
     .pipe(map(changes => {
       return changes.map(action => {
         const data = action.payload.doc.data() as Menu;
         data.id = action.payload.doc.id; 
         return data;
       });
     }));
  }

}
