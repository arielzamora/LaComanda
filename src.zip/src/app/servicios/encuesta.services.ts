import { Injectable } from '@angular/core';
//remplazo por firebase import { HttpBase } from './http-base.service';
import { Observable } from 'rxjs';
import { map, tap, catchError, timeInterval } from 'rxjs/operators';
import { Encuesta } from '../clases/Encuesta';
import { analyzeAndValidateNgModules } from '@angular/compiler';

import {AngularFirestore,AngularFirestoreCollection,AngularFirestoreDocument}from '@angular/fire/firestore';
import { firestore } from 'firebase';
import {Menu} from '../clases/Menu';
import {Empleado} from '../clases/Empleado';
import {MenuService} from './menu.service';
import {EmpleadoService} from './empleado.service';
import { Timestamp } from 'rxjs/internal/operators/timestamp';

@Injectable({
  providedIn: 'root'
})
export class encuestaservice {

   retorno: Observable<Encuesta[]>;
   retornoPromiso:Promise<Object>;
   menu:Menu;
   empleado:Empleado;
   EncuestaModel:Encuesta;

   private encuestaColeccion:AngularFirestoreCollection<Encuesta>;
   private encuestaDoc:AngularFirestoreDocument<Encuesta>;
   private encuestas:Observable<Encuesta[]>;
   //private Encuesta:Observable<Encuesta>;

  constructor(private afs:AngularFirestore,private menuService:MenuService,private empService:EmpleadoService) {
    this.encuestaColeccion=afs.collection<Encuesta>('Encuesta');
    this.encuestas=this.encuestaColeccion.valueChanges();
  }



  public ListarPorMesa(codigoMesa: string): Observable<Encuesta[]> {

    //return this.miHttp.httpGetO<Encuesta[]>('Encuesta/listarPorMesa/' + codigoMesa);
    this.encuestaColeccion=this.afs.collection<Encuesta>('Encuesta',x=>x.where("idMesa","==",codigoMesa));
    return this.encuestas=this.encuestaColeccion.snapshotChanges()
    .pipe(map(changes => {
      return changes.map(action => {
        const data = action.payload.doc.data() as Encuesta;
        data.id = action.payload.doc.id; 
        return data;
      });
    }));

  
  }

  public ListarActivosPorSector(): Observable<Encuesta[]> {
      //return this.miHttp.httpGetO<Encuesta[]>('Encuesta/listarPorMesa/' + codigoMesa);
      this.encuestaColeccion=this.afs.collection<Encuesta>('Encuesta',x=>x.where("idMesa","==","codigoMesa"));
      return this.encuestas=this.encuestaColeccion.snapshotChanges()
      .pipe(map(changes => {
        return changes.map(action => {
          const data = action.payload.doc.data() as Encuesta;
          data.id = action.payload.doc.id; 
          return data;
        });
      }));
  }


  public ListarTodos(): Observable<Encuesta[]> {
    this.encuestaColeccion=this.afs.collection<Encuesta>('Encuesta');
    return this.encuestas=this.encuestaColeccion.snapshotChanges()
     .pipe(map(changes => {
       return changes.map(action => {
         const data = action.payload.doc.data() as Encuesta;
         data.id = action.payload.doc.id; 
         return data;
       });
     }));
  }


  public Registrar(Encuesta:Encuesta): Promise<Object> {
   

            //Encuesta.cliente="";
            //Encuesta.descripcion="";
         //   Encuesta.estado="Pendiente";
         //   Encuesta.fecha=firestore.Timestamp.now();
         //   Encuesta.horaEstimada=firestore.Timestamp.now();
         //   Encuesta.horaFinal=firestore.Timestamp.now();
         //   Encuesta.horaInicial=firestore.Timestamp.now();
           // Encuesta.idEmpleado="";
           // Encuesta.idMenu="";
           // Encuesta.idMesa="";
           // Encuesta.importe=0;
           // Encuesta.nombreMozo="";
           // Encuesta.sector="";
     
    
    this.encuestaColeccion=this.afs.collection<Encuesta>('Encuesta');
    return new Promise((resolve, reject) => {

    this.encuestaColeccion.add(Encuesta).then(result=>{       
      resolve(result);
      }).catch(err => {
        reject(err);
      });
          
    })
  }

  public Cancelar(Encuesta: Encuesta) {
    //return this.miHttp.httpDeleteP('Encuesta/' + codigo);
    return this.retornoPromiso; 
  }




  }


/* <?php
include_once("DB/AccesoDatos.php");
class Encuesta
{
    public $codigo;
    public $estado;
    public $mesa;
    public $descripcion;
    public $id_menu;
    public $sector;
    public $nombre_cliente;
    public $nombre_mozo;
    public $id_mozo;
    public $id_encargado;
    public $hora_inicial;
    public $hora_entrega_estimada;
    public $hora_entrega_real;
    public $fecha;
    public $importe;
    ///Registra un nuevo Encuesta
    public static function Registrar($id_mesa, $id_menu, $id_mozo, $nombre_cliente)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        try {
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT Count(*) FROM menu m, mesa me, empleado em
                                                            INNER JOIN tipoempleado te ON em.ID_tipo_empleado = te.id_tipo_empleado 
                                                            WHERE m.id = :id_menu AND em.ID_empleado = :id_mozo
                                                            AND me.codigo_mesa = :id_mesa AND em.estado = 'A' AND te.Descripcion = 'Mozo';");
            $consulta->bindValue(':id_menu', $id_menu, PDO::PARAM_INT);
            $consulta->bindValue(':id_mozo', $id_mozo, PDO::PARAM_INT);
            $consulta->bindValue(':id_mesa', $id_mesa, PDO::PARAM_STR);
            $consulta->execute();
            $validacion = $consulta->fetch();
            if ($validacion[0] > 0) {
                $codigo = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                date_default_timezone_set("America/Argentina/Buenos_Aires");
                $fecha = date('Y-m-d');
                $hora_inicial = date('H:i');
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO Encuesta (codigo, id_estado_encuestas, fecha, hora_inicial, 
                                                                id_mesa, id_menu, id_mozo, nombre_cliente) 
                                                                VALUES (:codigo, 1, :fecha, :hora_inicial, 
                                                                :id_mesa, :id_menu, :id_mozo, :nombre_cliente);");
                $consulta->bindValue(':id_menu', $id_menu, PDO::PARAM_INT);
                $consulta->bindValue(':id_mozo', $id_mozo, PDO::PARAM_INT);
                $consulta->bindValue(':id_mesa', $id_mesa, PDO::PARAM_STR);
                $consulta->bindValue(':nombre_cliente', $nombre_cliente, PDO::PARAM_STR);
                $consulta->bindValue(':fecha', $fecha, PDO::PARAM_STR);
                $consulta->bindValue(':hora_inicial', $hora_inicial, PDO::PARAM_STR);
                $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
                $consulta->execute();
                $respuesta = array("Estado" => "OK", "Mensaje" => "Encuesta registrado correctamente.");
            } else {
                $respuesta = array("Estado" => "ERROR", "Mensaje" => "Alguno de los ID ingresados es inválido.");
            }
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Cancelar Encuesta.
    public static function Cancelar($codigo)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE Encuesta SET id_estado_encuestas = 5 WHERE codigo = :codigo");
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "Encuesta cancelado correctamente.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Listado completo de encuestas
    public static function ListarTodos()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo");
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Encuesta por codigo.
    public static function ObtenerPorCodigo($codigo)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                        WHERE p.codigo = :codigo");
            
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Listado completo de encuestas por fecha
    public static function ListarTodosPorFecha($fecha)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                        WHERE p.fecha = :fecha");
            $consulta->bindValue(':fecha', $fecha, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Listado de encuestas por mesa. No muestra cancelados ni finalizados.  
    public static function ListarPorMesa($mesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                        WHERE p.id_mesa = :mesa AND ep.descripcion NOT IN ('Cancelado','Finalizado')");
            $consulta->bindValue(':mesa', $mesa, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Listado de encuestas por sector. No muestra cancelados ni finalizados.
    public static function ListarActivosPorSector($sector, $id_empleado)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            switch ($sector) {
            //Si es socio los lista a todos.
                case "Socio":
                    $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                                me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                                em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                                p.hora_entrega_real, p.fecha, me.precio as importe
                                                                FROM Encuesta p
                                                                INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                                INNER JOIN menu me ON me.id = p.id_menu
                                                                INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                                INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                                WHERE ep.descripcion NOT IN ('Cancelado','Finalizado')");
                    break;
            //Si es mozo lista los de ese mozo.
                case "Mozo":
                    $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                            me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                            em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                            p.hora_entrega_real, p.fecha, me.precio as importe
                                                            FROM Encuesta p
                                                            INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                            INNER JOIN menu me ON me.id = p.id_menu
                                                            INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                            INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                            WHERE p.id_mozo = :id_mozo AND ep.descripcion NOT IN ('Cancelado','Finalizado')");
                    $consulta->bindValue(':id_mozo', $id_empleado, PDO::PARAM_STR);
                    break;
            //Para los demás lista por sector.
                default:
                    $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                            me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                            em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                            p.hora_entrega_real, p.fecha, me.precio as importe
                                                            FROM Encuesta p
                                                            INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                            INNER JOIN menu me ON me.id = p.id_menu
                                                            INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                            INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                            WHERE te.descripcion = :sector AND ep.descripcion NOT IN ('Cancelado','Finalizado','Entregado','Listo para Servir')");
                    $consulta->bindValue(':sector', $sector, PDO::PARAM_STR);
                    break;
            }
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Listado de encuestas cancelados.
    public static function ListarCancelados()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                        WHERE ep.descripcion = 'Cancelado'");
            $consulta->execute();
            $resultado = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Uno de los empleados toma el Encuesta para prepararlo, agregando un tiempo estimado de preparación. 
    public static function TomarEncuesta($codigo, $id_encargado, $minutosEstimadosDePreparacion)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $time = new DateTime('now',new DateTimeZone('America/Argentina/Buenos_Aires'));
            $time->add(new DateInterval('PT' . $minutosEstimadosDePreparacion . 'M'));
            $hora_entrega_estimada = $time->format('H:i');
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE Encuesta SET id_estado_encuestas = 2, id_encargado = :id_encargado, 
                                                            hora_entrega_estimada = :hora_entrega_estimada WHERE codigo = :codigo");
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->bindValue(':hora_entrega_estimada', $hora_entrega_estimada, PDO::PARAM_STR);
            $consulta->bindValue(':id_encargado', $id_encargado, PDO::PARAM_INT);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "Encuesta tomado correctamente.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Se informa que el Encuesta está listo para servir.
    public static function InformarListoParaServir($codigo)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $time = new DateTime('now',new DateTimeZone('America/Argentina/Buenos_Aires'));
            $hora_entrega_real = $time->format('H:i');
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE Encuesta SET id_estado_encuestas = 3, hora_entrega_real = :hora_entrega_real 
                                                            WHERE codigo = :codigo");
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->bindValue(':hora_entrega_real', $hora_entrega_real, PDO::PARAM_STR);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "Encuesta listo para servir.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Se informa que el Encuesta fue entregado a la mesa.
    public static function Servir($codigo)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE Encuesta SET id_estado_encuestas = 4 
                                                            WHERE codigo = :codigo");
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "Encuesta servido correctamente.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Devuelve el tiempo restante 
    public static function TiempoRestante($codigo)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.hora_entrega_estimada, ep.descripcion as estado FROM Encuesta p
                                                            INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                            WHERE p.codigo = :codigo");
            $consulta->bindValue(':codigo', $codigo, PDO::PARAM_STR);
            $consulta->execute();
            $Encuesta = $consulta->fetch();
            if($Encuesta["estado"] == 'En Preparacion'){
                $time = new DateTime('now',new DateTimeZone('America/Argentina/Buenos_Aires'));
                $hora_entrega = new DateTime($hora_entrega_estimada[0],new DateTimeZone('America/Argentina/Buenos_Aires'));
                if($time > $hora_entrega){
                    $resultado = "Encuesta retrasado.";
                }else{
                    $intervalo = $time->diff($hora_entrega);
                    $resultado = $intervalo->format('%H:%I:%S');
                }                
            }
            else{
                $resultado = array("Estado" => "ERROR", "Mensaje" => "El Encuesta se encuentra ".$Encuesta["estado"]);
            }
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Finaliza los encuestas de la mesa
    public static function Finalizar($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE Encuesta SET id_estado_encuestas = 6 
                                                            WHERE id_estado_encuestas <> 5 AND id_mesa = :codigo");
            $consulta->bindValue(':codigo', $codigoMesa, PDO::PARAM_STR);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "encuestas de la mesa finalizados correctamente.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Lo más vendido
    public static function MasVendido()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.id_menu, m.nombre, count(p.id_menu) as cantidad_ventas FROM Encuesta p INNER JOIN menu m
                                                            on m.id = p.id_menu GROUP BY(id_menu) HAVING count(p.id_menu) = 
                                                            (SELECT MAX(sel.cantidad_ventas) FROM 
                                                            (SELECT count(p.id_menu) as cantidad_ventas FROM Encuesta p GROUP BY(id_menu)) sel);");
            $consulta->execute();
            $respuesta = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    ///Lo más vendido
    public static function MenosVendido()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.id_menu, m.nombre, count(p.id_menu) as cantidad_ventas FROM Encuesta p INNER JOIN menu m
                                                            on m.id = p.id_menu GROUP BY(id_menu) HAVING count(p.id_menu) = 
                                                            (SELECT MIN(sel.cantidad_ventas) FROM 
                                                            (SELECT count(p.id_menu) as cantidad_ventas FROM Encuesta p GROUP BY(id_menu)) sel);");
            $consulta->execute();
            $respuesta = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
    //Lista los encuestas fuera del tiempo estipulado.
    public static function ListarFueraDelTiempoEstipulado()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT p.codigo, ep.descripcion as estado, p.id_mesa as mesa, 
                                                        me.nombre as descripcion, p.id_menu, te.descripcion as sector, p.nombre_cliente,
                                                        em.nombre_empleado as nombre_mozo, p.id_mozo, p.id_encargado, p.hora_inicial, p.hora_entrega_estimada,
                                                        p.hora_entrega_real, p.fecha, me.precio as importe
                                                        FROM Encuesta p
                                                        INNER JOIN estado_encuestas ep ON ep.id_estado_encuestas = p.id_estado_encuestas
                                                        INNER JOIN menu me ON me.id = p.id_menu
                                                        INNER JOIN tipoempleado te ON te.id_tipo_empleado = me.id_sector 
                                                        INNER JOIN empleado em ON em.ID_empleado = p.id_mozo
                                                        WHERE p.hora_entrega_estimada < p.hora_entrega_real");
            $consulta->execute();
            $respuesta = $consulta->fetchAll(PDO::FETCH_CLASS, "Encuesta");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }
}
?> */