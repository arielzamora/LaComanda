//import { HttpBase } from './http-base.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, tap, catchError, timeInterval } from 'rxjs/operators';
import { Mesa } from '../clases/Mesa';


import {AngularFirestore,AngularFirestoreCollection,AngularFirestoreDocument}from '@angular/fire/firestore';
import { firestore } from 'firebase';

@Injectable({
  providedIn: 'root'
})
export class MesasService {

  retorno:Observable<Mesa[]>;
  returnPromesa:Promise<any> ;


  private mesaColeccion:AngularFirestoreCollection<Mesa>;
  private mesaDoc:AngularFirestoreDocument<Mesa>;
  private mesas:Observable<Mesa[]>;
  private mesa:Observable<Mesa>;

  constructor(private afs:AngularFirestore) { 

    this.mesaColeccion=afs.collection<Mesa>('Mesa');
    this.mesas=this.mesaColeccion.valueChanges();

  }

  public Listar(): Observable<Mesa[]> {
    this.mesaColeccion=this.afs.collection<Mesa>('Mesa');
    return this.mesas=this.mesaColeccion.snapshotChanges()
     .pipe(map(changes => {
       return changes.map(action => {
         const data = action.payload.doc.data() as Mesa;
         data.id = action.payload.doc.id; 
         return data;
       });
     }));
  }

  public ObtenerMesa(codigo:string):Observable<Mesa[]>{
    this.mesaColeccion=this.afs.collection<Mesa>('Mesa',x=>x.where("codigo","==",codigo));
    return this.mesas=this.mesaColeccion.snapshotChanges()
    .pipe(map(changes => {
      return changes.map(action => {
        const data = action.payload.doc.data() as Mesa;
        //data.id = action.payload.doc.id; me pisa el id del user con el del documento
        return data;
      });
    }));
  }

  public Registrar(mesa:Mesa): Promise<any> {

    this.mesaColeccion=this.afs.collection<Mesa>('Mesa');
    return new Promise((resolve, reject) => {

       mesa.estado="Activa";

    this.mesaColeccion.add(mesa).then(result => {
      resolve(true);
      }).catch(err => {
        reject(false);
      });
    
    })
  }

  public Eliminar(mesa: Mesa): Promise<Object> {
       //MODIFICO EMPLEADO       

       //empleado.fechaRegistro= firestore.Timestamp.now();
      
       mesa.estado="Eliminada";

       return new Promise((resolve, reject) => {
       this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
       
       this.mesaDoc.update(mesa).then(result => {
         resolve(true);
         }).catch(err => {
           reject(false);
         });
       
     })
  }

  public ActualizarFoto(codigo: string, foto): Promise<Object> {
    const request: Object = {
      codigo: codigo,
      foto: foto
    };

    const json = JSON.stringify(request);
    //return this.miHttp.httpPostP('mesas/foto/', request);
    return this.returnPromesa;
  }

  public CambiarEstadoEsperando(mesa: Mesa): Promise<any> {
      //MODIFICO EMPLEADO       
     
      //empleado.fechaRegistro= firestore.Timestamp.now();
      mesa.estado="Con cliente esperando pedido";

      return new Promise((resolve, reject) => {
      this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
      
      this.mesaDoc.update(mesa).then(result => {
        resolve(true);
        }).catch(err => {
          reject(false);
        });
      
    })
  }

  public CambiarEstadoComiendo(mesa: Mesa): Promise<any> {
      //MODIFICO EMPLEADO       

      //empleado.fechaRegistro= firestore.Timestamp.now();
      mesa.estado="Con clientes comiendo";
  
      return new Promise((resolve, reject) => {
      this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
      
      this.mesaDoc.update(mesa).then(result => {
        resolve(true);
        }).catch(err => {
          reject(false);
        });
      
    })
  }

  public CambiarEstadoPagando(mesa: Mesa): Promise<any> {
      //MODIFICO EMPLEADO       
     // empleado.fechaRegistro= firestore.Timestamp.now();

     mesa.estado="Con clientes pagando";
  
      return new Promise((resolve, reject) => {
      this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
      
      this.mesaDoc.update(mesa).then(result => {
        resolve(true);
        }).catch(err => {
          reject(false);
        });
      
    })
  }

  public CambiarEstadoCerrada(mesa: Mesa): Promise<any> {
      //MODIFICO EMPLEADO       

      //empleado.fechaRegistro= firestore.Timestamp.now();
      mesa.estado="Cerrada";
  
      return new Promise((resolve, reject) => {
      this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
      
      this.mesaDoc.update(mesa).then(result => {
        resolve(true);
        }).catch(err => {
          reject(false);
        });
      
    })
  }

  public Cobrar(mesa: Mesa): Promise<any> {
      //MODIFICO EMPLEADO       

      //empleado.fechaRegistro= firestore.Timestamp.now();
      mesa.estado="Cobrada";

      return new Promise((resolve, reject) => {
      this.mesaDoc=this.afs.doc<Mesa>('Mesa/'+mesa.id);
      
      this.mesaDoc.update(mesa).then(result => {
        resolve(true);
        }).catch(err => {
          reject(false);
        });
      
    })
  }

}
/*
    ///Cambio de estado: Con cliente esperando pedido
    public static function EstadoEsperandoPedido($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE mesa SET estado = 'Con cliente esperando pedido' WHERE codigo_mesa = :codigo");
            $consulta->bindValue(':codigo', $codigoMesa, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = array("Estado" => "OK", "Mensaje" => "Cambio de estado exitoso.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Cambio de estado: Con clientes comiendo
    public static function EstadoComiendo($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE mesa SET estado = 'Con clientes comiendo' WHERE codigo_mesa = :codigo");
            $consulta->bindValue(':codigo', $codigoMesa, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = array("Estado" => "OK", "Mensaje" => "Cambio de estado exitoso.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Cambio de estado: Con clientes pagando
    public static function EstadoPagando($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE mesa SET estado = 'Con clientes pagando' WHERE codigo_mesa = :codigo");
            $consulta->bindValue(':codigo', $codigoMesa, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = array("Estado" => "OK", "Mensaje" => "Cambio de estado exitoso.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Cambio de estado: Cerrada
    public static function EstadoCerrada($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE mesa SET estado = 'Cerrada' WHERE codigo_mesa = :codigo");
            $consulta->bindValue(':codigo', $codigoMesa, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = array("Estado" => "OK", "Mensaje" => "Cambio de estado exitoso.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Calcula el importe final y genera la factura. Finaliza todos los pedidos de la mesa. 
    public static function Cobrar($codigoMesa)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $pedidos = Pedido::ListarPorMesa($codigoMesa);
            $importeFinal = 0;
            foreach($pedidos as $pedido){
                if($pedido->estado == "Entregado"){
                    $importeFinal += $pedido->importe;
                }
            }
            Factura::Generar($importeFinal,$codigoMesa);
            Pedido::Finalizar($codigoMesa);
            $resultado = array("Estado" => "OK", "Mensaje" => "Se ha cobrado a la mesa con exito.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa más usada
    public static function MasUsada()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, count(f.codigoMesa) as cantidad_usos FROM factura f 
                                                            GROUP BY(f.codigoMesa) HAVING count(f.codigoMesa) = 
                                                            (SELECT MAX(sel.cantidad_usos) FROM 
                                                            (SELECT count(f2.codigoMesa) as cantidad_usos FROM factura f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    
    ///Mesa más usada
    public static function MenosUsada()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, count(f.codigoMesa) as cantidad_usos FROM factura f 
                                                            GROUP BY(f.codigoMesa) HAVING count(f.codigoMesa) = 
                                                            (SELECT MIN(sel.cantidad_usos) FROM 
                                                            (SELECT count(f2.codigoMesa) as cantidad_usos FROM factura f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que más facturó
    public static function MasFacturacion()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, SUM(f.importe) as facturacion_total FROM factura f 
                                                            GROUP BY(f.codigoMesa) HAVING SUM(f.importe) = 
                                                            (SELECT MAX(sel.facturacion_total) FROM
                                                            (SELECT SUM(f2.importe) as facturacion_total FROM factura f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que menos facturó
    public static function MenosFacturacion()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, SUM(f.importe) as facturacion_total FROM factura f 
                                                            GROUP BY(f.codigoMesa) HAVING SUM(f.importe) = 
                                                            (SELECT MIN(sel.facturacion_total) FROM
                                                            (SELECT SUM(f2.importe) as facturacion_total FROM factura f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que tiene la factura con más importe
    public static function ConFacturaConMasImporte()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, f.importe as importe FROM factura f WHERE f.importe = 
                                                            (SELECT MAX(f2.importe) as importe FROM factura f2 ) GROUP BY (f.codigoMesa);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que tiene la factura con menos importe
    public static function ConFacturaConMenosImporte()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, f.importe as importe FROM factura f WHERE f.importe = 
                                                            (SELECT MIN(f2.importe) as importe FROM factura f2 ) GROUP BY (f.codigoMesa);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que tiene la mejor puntuacion
    public static function ConMejorPuntuacion()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, AVG(f.puntuacion_mesa) as puntuacion_promedio FROM encuesta f 
                                                            GROUP BY(f.codigoMesa) HAVING AVG(f.puntuacion_mesa) = 
                                                            (SELECT MAX(sel.puntuacion_promedio) FROM
                                                            (SELECT AVG(f2.puntuacion_mesa) as puntuacion_promedio FROM encuesta f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Mesa que tiene la peor puntuacion
    public static function ConPeorPuntuacion()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, AVG(f.puntuacion_mesa) as puntuacion_promedio FROM encuesta f 
                                                            GROUP BY(f.codigoMesa) HAVING AVG(f.puntuacion_mesa) = 
                                                            (SELECT MIN(sel.puntuacion_promedio) FROM
                                                            (SELECT AVG(f2.puntuacion_mesa) as puntuacion_promedio FROM encuesta f2 GROUP BY(f2.codigoMesa)) sel);");
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
    ///Facturacion entre 2 fechas para una mesa
    public static function FacturacionEntreFechas($codigoMesa,$fecha1,$fecha2)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT f.codigoMesa, f.fecha, f.importe FROM factura f 
                                                            WHERE f.codigoMesa = :codigoMesa AND f.fecha BETWEEN :fecha1 AND :fecha2;");
            $consulta->bindValue(':codigoMesa', $codigoMesa, PDO::PARAM_STR);
            $consulta->bindValue(':fecha1', $fecha1, PDO::PARAM_STR);
            $consulta->bindValue(':fecha2', $fecha2, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = $consulta->fetchAll();
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $resultado = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $resultado;
        }
    }
}

 */