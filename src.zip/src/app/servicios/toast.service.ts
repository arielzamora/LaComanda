import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class ToastService {

  //constructor(private toastController: ToastController) {
 constructor() {
      
     }

  errorToast(message: string) {
    /* this.toastController.create({
      message: message,
      showCloseButton: true,
      color: 'danger',
      closeButtonText: 'Cerrar',
      duration: 2000
    })
    .then( res => {
      res.present();
    }); */
  }

  confirmationToast(message: string) {
   /*  this.toastController.create({
      message: message,
      showCloseButton: true,
      color: 'success',
      closeButtonText: 'Cerrar',
      duration: 2000
    })
    .then( res => {
      res.present();
    }); */
  }
}
