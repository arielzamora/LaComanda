import { OperacionesPorSector } from './../clases/OperacionesPorSector';
import { Empleado } from '../clases/Empleado';

import { Injectable } from '@angular/core';
import {AngularFirestore,AngularFirestoreCollection,AngularFirestoreDocument}from '@angular/fire/firestore';
import {Observable}from 'rxjs/internal/Observable';
import {map}from 'rxjs/operators';
import { firestore } from 'firebase';



@Injectable({
  providedIn: 'root'
})
export class EmpleadoService {

  retorno :Observable<Empleado[]>;
  operacionesSector: Array<any> = new Array<any>();
  retornoPromesa:Promise<Object>;

  private empleadoColeccion:AngularFirestoreCollection<Empleado>;
  private empleadoDoc:AngularFirestoreDocument<Empleado>;
  private empleados:Observable<Empleado[]>;
  //private empleado:Observable<Empleado>;
  public operaciones:OperacionesPorSector;

  constructor(private afs:AngularFirestore) { 
    this.empleadoColeccion=afs.collection<Empleado>('Empleado');
    this.empleados=this.empleadoColeccion.valueChanges();
  }



  public Listar(): Observable<Empleado[]> {
    this.empleadoColeccion=this.afs.collection<Empleado>('Empleado');
   return this.empleados=this.empleadoColeccion.snapshotChanges()
    .pipe(map(changes => {
      return changes.map(action => {
        const data = action.payload.doc.data() as Empleado;
        data.id = action.payload.doc.id; //me pisa el id del user con el del documento
        return data;
      });
    }));
  }

  //tengo que dar de alta el usuario y el rol 
  public Registrar(empleado:Empleado): Promise<Object> {
    this.empleadoColeccion=this.afs.collection<Empleado>('Empleado');
    return new Promise((resolve, reject) => {
    //REGISTRO USUARIO CORREO IMAGEN Y EMPLEADO
    empleado.fechaRegistro= firestore.Timestamp.now();
    empleado.ultimoLogin=firestore.Timestamp.now();
    this.empleadoColeccion.add(empleado).then(result=>{       
      resolve(true);
      }).catch(err => {
        reject(false);
      });
          
    })
    
  }

  //despues de insertado ,obtengo el empleado para pguardar su id de documento al id de empleado
  obtenerEmpleado(idUser: string): Observable<Empleado[]>{
 
    this.empleadoColeccion=this.afs.collection<Empleado>('Empleado',x=>x.where("idUser","==",idUser));
     return this.empleados=this.empleadoColeccion.snapshotChanges()
     .pipe(map(changes => {
       return changes.map(action => {
         const data = action.payload.doc.data() as Empleado;
          data.id = action.payload.doc.id; 
          data.idUser=idUser;
         return data;
       });
     }));

   }
   
  public Modificar(empleado:Empleado): Promise<Object> {
 
    //MODIFICO EMPLEADO       
    let idEmpleado=empleado.id;
    empleado.fechaRegistro= firestore.Timestamp.now();

    return new Promise((resolve, reject) => {
    this.empleadoDoc=this.afs.doc<Empleado>('Empleado/'+idEmpleado);
    
    this.empleadoDoc.update(empleado).then(result => {
      resolve(true);
      }).catch(err => {
        reject(false);
      });
    
  })

  }

  public Baja(empleado: Empleado): Promise<Object>{

    let idEmpleado=empleado.id;
    empleado.estado="B";
    empleado.fechaRegistro= firestore.Timestamp.now();
  

    return new Promise((resolve, reject) => {

    this.empleadoDoc=this.afs.doc<Empleado>('Empleado/'+idEmpleado);
      
    this.empleadoDoc.update(empleado).then(resolved=>{
      resolve(true);
    }).catch(err=>{
      reject(false);
    });

    })

    }

  public Activar(empleado: Empleado): Promise<Object> {
    //return this.miHttp.httpGetP('empleados/activar/' + id);

    let idEmpleado=empleado.id;
    empleado.estado="A";
    empleado.fechaRegistro= firestore.Timestamp.now();
  

    return new Promise((resolve, reject) => {

    this.empleadoDoc=this.afs.doc<Empleado>('Empleado/'+idEmpleado);
     
    this.empleadoDoc.update(empleado).then(resolved=>{
      resolve(true);
    }).catch(err=>{
      reject(false);
    });

    })

  }

  public Suspender(empleado:Empleado): Promise<Object> {
    //return this.miHttp.httpDeleteP('empleados/suspender/' + id);


    let idEmpleado=empleado.id;
    empleado.estado="S";
    empleado.fechaRegistro= firestore.Timestamp.now();

    return new Promise((resolve, reject) => {

    this.empleadoDoc=this.afs.doc<Empleado>('Empleado/'+idEmpleado);
    this.empleadoDoc.update(empleado).then(resolved=>{
      resolve(true);
    }).catch(err=>{
      reject(false);
    });
    
  })

  }

  public CambiarClave(empleado:Empleado): Promise<Object>{
    
    let idEmpleado=empleado.id;
    empleado.fechaRegistro= firestore.Timestamp.now();
    

    return new Promise((resolve, reject) => {

    this.empleadoDoc=this.afs.doc<Empleado>('Empleado/'+idEmpleado);
    this.empleadoDoc.update(empleado).then(resolved=>{
      resolve(true);
    }).catch(err=>{
      reject(false);
    });    
   })


  }

  public CantidadOperacionesPorSector():Array<OperacionesPorSector> {
     
    let listaEmpleados;
          this.empleadoColeccion=this.afs.collection<Empleado>('Empleado');
          
          let empleados=this.empleadoColeccion.snapshotChanges()
            .pipe(map(changes => {
              return changes.map(action => {
                const data = action.payload.doc.data() as Empleado;
                data.id = action.payload.doc.id; //me pisa el id del user con el del documento
                this.operaciones.sector=data.tipo;
                this.operaciones.cantidad_operaciones=data.cantidad_operaciones;
                this.operacionesSector.push(this.operaciones);

              });
            }));
            return this.operacionesSector;
  }

} 
/* public static function SumarOperacion($id_empleado)
{
    try {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE empleado 
                                                        SET cantidad_operaciones = cantidad_operaciones + 1
                                                        WHERE id_empleado = :id_empleado");
        $consulta->bindValue(':id_empleado', $id_empleado, PDO::PARAM_INT);
        $consulta->execute();
        $respuesta = array("Estado" => "OK", "Mensaje" => "Operación sumada correctamente.");
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
    }
    finally {
        return $respuesta;
    }
}
///Cantidad de operaciones de todos por sector
public static function CantidadOperacionesPorSector()
{
    try {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT te.descripcion as sector, SUM(em.cantidad_operaciones) as cantidad_operaciones FROM empleado em
                                                        INNER JOIN tipoempleado te on em.id_tipo_empleado = te.id_tipo_empleado
                                                        GROUP BY(te.descripcion)");
        $consulta->execute();
        $respuesta = $consulta->fetchAll();
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
    }
    finally {
        return $respuesta;
    }
}
///Cantidad de operaciones de todos por sector
public static function CantidadOperacionesEmpleadosPorSector($sector)
{
    try {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT te.descripcion as sector, em.nombre_empleado, em.id_empleado, 
                                                        em.cantidad_operaciones as cantidad_operaciones FROM empleado em
                                                        INNER JOIN tipoempleado te on em.id_tipo_empleado = te.id_tipo_empleado WHERE te.descripcion = :sector");
        $consulta->bindValue(':sector', $sector, PDO::PARAM_STR);
        $consulta->execute();
        $respuesta = $consulta->fetchAll();
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
    }
    finally {
        return $respuesta;
    }
}
///Listado completo de empleados entre fechas de login
public static function ListarEntreFechasLogin($fecha1,$fecha2)
{
    try {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT em.ID_empleado as id, te.Descripcion as tipo, em.nombre_empleado as nombre, 
                                                    em.usuario, em.fecha_registro as fechaRegistro, em.fecha_ultimo_login as ultimoLogin, em.estado,
                                                    em.cantidad_operaciones 
                                                    FROM empleado em INNER JOIN tipoempleado te on em.id_tipo_empleado = te.id_tipo_empleado
                                                    WHERE fecha_ultimo_login BETWEEN :fecha1 AND :fecha2");
        $consulta->bindValue(':fecha1', $fecha1, PDO::PARAM_STR);
        $consulta->bindValue(':fecha2', $fecha2, PDO::PARAM_STR);
        $consulta->execute();
        $respuesta = $consulta->fetchAll(PDO::FETCH_CLASS, "Empleado");
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
    }
    finally {
        return $respuesta;
    }
}
///Listado completo de empleados entre fechas de registro
public static function ListarEntreFechasRegistro($fecha1,$fecha2)
{
    try {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT em.ID_empleado as id, te.Descripcion as tipo, em.nombre_empleado as nombre, 
                                                    em.usuario, em.fecha_registro as fechaRegistro, em.fecha_ultimo_login as ultimoLogin, em.estado,
                                                    em.cantidad_operaciones 
                                                    FROM empleado em INNER JOIN tipoempleado te on em.id_tipo_empleado = te.id_tipo_empleado
                                                    WHERE fecha_registro BETWEEN :fecha1 AND :fecha2");
        $consulta->bindValue(':fecha1', $fecha1, PDO::PARAM_STR);
        $consulta->bindValue(':fecha2', $fecha2, PDO::PARAM_STR);
        $consulta->execute();
        $respuesta = $consulta->fetchAll(PDO::FETCH_CLASS, "Empleado");
    } catch (Exception $e) {
        $mensaje = $e->getMessage();
        $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
    }
    finally {
        return $respuesta;
    }
}
}
 */