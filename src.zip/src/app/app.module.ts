import { CaptchaService } from './servicios/captcha.service';
import { CsvComponent } from './componentes/Common/csv/csv.component';
import { EmpleadoService } from './servicios/empleado.service';
import { EmpleadosRegistroComponent } from './componentes/empleados-board/empleados-registro/empleados-registro.component';
import { EmpleadosListComponent } from './componentes/empleados-board/empleados-list/empleados-list.component';
import { EmpleadosBoardComponent } from './componentes/empleados-board/empleados-board.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { BienvenidaComponent } from './componentes/bienvenida/bienvenida.component';
import { AppRoutingModule } from './Routes/app-routing.module';
import { NavegacionComponent } from './componentes/navegacion/navegacion.component';
import { ClientesComponent } from './componentes/clientes/clientes.component';
import { EmpleadosComponent } from './componentes/empleados/empleados.component';
import { MatSidenavModule, MatCardModule, MatButtonModule, MatFormFieldModule, MatIconModule, MatExpansionModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpBase } from './servicios/http-base.service';
import { PedidoService } from './servicios/pedido.service';
import { EmpleadosLoginComponent } from './componentes/empleados-login/empleados-login.component';
import { PerfilComponent } from './componentes/empleados-login/perfil/perfil.component';
import { ErrorInterceptor } from './servicios/Interceptors/ErrorInterceptor';
import { JwtInterceptor } from './servicios/Interceptors/JWTInterceptor';
import { JwtHelperService, JwtModule } from '@auth0/angular-jwt';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { SpinnerInterceptor } from './servicios/Interceptors/SpinnerInterceptor';
 import { NgxCaptchaModule } from 'ngx-captcha';
 import { ChartModule } from 'angular2-highcharts';
import { EmpleadosChartsComponent } from './componentes/empleados-board/empleados-charts/empleados-charts.component';
import { Angular2CsvModule } from 'angular2-csv';
import { EmpleadosModifyComponent } from './componentes/empleados-board/empleados-modify/empleados-modify.component';
 import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { PedidosMesaComponent } from './componentes/clientes/pedidos-mesa/pedidos-mesa.component';
import { OrdenarPipe } from './Pipes/ordenar.pipe';
import { EstadoPipe } from './Pipes/Estado.pipe';
import { SectorPipe } from './Pipes/Sector.pipe';
import { DateFirePipe } from './Pipes/dateFire.pipe';
import { PanelDirective } from './Directives/panel.directive';
import { EstadoPedidoDirective } from './Directives/estado-pedido.directive';
import { AccionPedidoDirective } from './Directives/accion-pedido.directive';
import { MesaBoardComponent } from './componentes/mesa-board/mesa-board.component';
import { MesaListComponent } from './componentes/mesa-board/mesa-list/mesa-list.component';
import { MesaRegistroComponent } from './componentes/mesa-board/mesa-registro/mesa-registro.component';
import { PedidosBoardComponent } from './componentes/pedidos-board/pedidos-board.component';
import { PedidosRegistroComponent } from './componentes/pedidos-board/pedidos-registro/pedidos-registro.component';
import { CaptchaComponent } from './componentes/Common/captcha/captcha.component';
import { ValidarRolesDirective } from './Directives/validar-roles.directive';
import { MenuService } from './servicios/menu.service';
import { EstadoPedidosPipe } from './Pipes/estado-pedidos.pipe';

//angular fire 
//import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
//import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFireAuthModule } from '@angular/fire/auth';

//firestore y imagenes 
import {AngularFireModule}from '@angular/fire';
import {AngularFireDatabaseModule}from '@angular/fire/database';
import {AngularFireAuth}from '@angular/fire/auth';
import {AngularFireStorageModule}from '@angular/fire/storage';
import {AngularFirestore}from '@angular/fire/firestore';
import {FormsModule}from '@angular/forms';

import { firebaseConfig } from 'src/environments/environment';
import { EncuestaComponent } from './componentes/clientes/encuesta/encuesta.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { SampleModule } from 'angular-pdf-generator';

export function getAccessToken() {
  return localStorage.getItem('token');
}

export function highchartsFactory() {
  const hc = require('highcharts');
  const dd = require('highcharts/modules/exporting');
  dd(hc);

  return hc;
}


@NgModule({
  declarations: [
    AppComponent,
    BienvenidaComponent,
    NavegacionComponent,
    ClientesComponent,
    EmpleadosComponent,
    EmpleadosLoginComponent,
    EmpleadosBoardComponent,
    EmpleadosListComponent,
    EmpleadosRegistroComponent,
    EmpleadosChartsComponent,
    EmpleadosModifyComponent,
    CsvComponent,
    PedidosMesaComponent,
    OrdenarPipe,
    EstadoPipe,
    SectorPipe,
    DateFirePipe,
    PanelDirective,
    EstadoPedidoDirective,
    AccionPedidoDirective,
    MesaBoardComponent,
    MesaListComponent,
    MesaRegistroComponent,
    PedidosBoardComponent,
    PedidosRegistroComponent,
    CaptchaComponent,
    ValidarRolesDirective,
    EstadoPedidosPipe,
    PerfilComponent,
    EncuestaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    AngularFireAuthModule,
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(firebaseConfig),
    MatSidenavModule,
    NoopAnimationsModule,
    NgxSpinnerModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxCaptchaModule,
    Angular2CsvModule,
    MatExpansionModule,
    NgbModule,
    ChartModule,
    SampleModule,
    [JwtModule.forRoot({
      config: {
        tokenGetter: (getAccessToken),
        whitelistedDomains: ['https://arielzamora.github.io', 'localhost:4200']
      }
    })]
  ],
  providers: [
    HttpBase,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SpinnerInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true
    },
   {
     provide: HighchartsStatic,
     useFactory: highchartsFactory
    },
    PedidoService,
    JwtHelperService,
    EmpleadoService,
    NgxSpinnerService,
    CaptchaService,
    MenuService,
    AngularFireAuth,//
    AngularFirestore//
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
