import { Pedido } from './../../clases/Pedido';
import { Component, OnInit, Output } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { PedidoService } from 'src/app/servicios/pedido.service';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.scss']
})
export class ClientesComponent implements OnInit {
  listaPedidos: Pedido[];
  codigoMesa: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private pedidosService: PedidoService
  ) {

      this.codigoMesa = this.route.snapshot.paramMap.get("codMesa")

  }

  ngOnInit(   
  ) { 

    this.cargarLista();
  }

  public cargarLista() {
    this.pedidosService.ListarPorMesa(this.codigoMesa).subscribe( response => {
      console.log(response);
      this.listaPedidos = response;
    },
    error => {
      console.error(error);
    });
  }
}
