import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,FormControl, Validators} from '@angular/forms';
import { encuestaservice } from 'src/app/servicios/encuesta.services';
import { Encuesta } from 'src/app/clases/Encuesta';
import { Router } from '@angular/router';
import { ClienteInterface } from 'src/app/clases/Cliente';

@Component({
  selector: 'app-encuesta',
  templateUrl: './encuesta.component.html',
  styleUrls: ['./encuesta.component.scss']
})
export class EncuestaComponent implements OnInit {
  selectedMesa = 4;
  selectedResto = 4;
  selectedMozo = 4;
  selectedCoci = 4;
  public form: FormGroup;
  error:boolean;
  errorMessage:string;
  encuesta:Encuesta={};
  clienteData:ClienteInterface={};

  constructor(private fb: FormBuilder,private encuestaService:encuestaservice,private router:Router) { }

  ngOnInit() {
    this.form = this.fb.group({
      comentario: ['', Validators.required]
    });
  }

  Submit()
  {


     this.errorMessage = '';
     this.error = false;


     if (this.form.valid) {

      this.getDatosPedido();

      this.encuesta.puntuacionMesa=this.selectedMesa;
      this.encuesta.puntuacionRestaurante=this.selectedResto;
      this.encuesta.puntuacionMozo=this.selectedMozo;
      this.encuesta.puntuacionCocinero=this.selectedCoci;
      this.encuesta.comentario=this.form.get('comentario').value;
      this.encuesta.codigoMesa=this.clienteData.mesa;
      this.encuesta.idMozo=this.clienteData.mozo;
      this.encuesta.idCliente=this.clienteData.cliente;

       this.encuestaService.Registrar(this.encuesta)
         .then(
           res => {                               
               //guardo el elmpeado
               this.router.navigate(["/Bienvenida"]);
 
           }
         )
         .catch(error => {
             this.error = true;
             //this.errorMessage = res['Mensaje'];
             if (error) {
               //this.toastService.error('Usuario no encontrado.');
             this.errorMessage='Error al Registrar encuesta.' + error;
             } 
           }
         );
     } else {
       this.errorMessage = 'Debe completar los campos correctamente.';
       this.error = true;
     }

  }

   getDatosPedido()
   {
    const data = localStorage.getItem('encuestaCli');

    this.clienteData=JSON.parse(data);  

   }

   Cancel(){
    this.router.navigate(["/Bienvenida"]);
   }
}
