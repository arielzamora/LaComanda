import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input, Output,ViewChild, EventEmitter } from '@angular/core';
import { Pedido } from './../../../clases/Pedido';
import { PedidoService } from './../../../servicios/pedido.service';

import { PedidosRegistroComponent } from './../../pedidos-board/pedidos-registro/pedidos-registro.component';
import { Angular2CsvComponent} from 'angular2-csv';
import { ClienteInterface } from 'src/app/clases/Cliente';
import * as PDF from 'jspdf';
import html2canvas from 'html2canvas';


@Component({
  selector: 'app-pedidos-mesa',
  templateUrl: './pedidos-mesa.component.html',
  styleUrls: ['./pedidos-mesa.component.scss']
})
export class PedidosMesaComponent implements OnInit {
  @Input() listaPedidos: Pedido[];
  @Input() esCliente: boolean;
  @Input() title: string;
  @Input() showTotal: boolean;
  @Output() refrescarEvent: EventEmitter<void>;
  form: FormGroup;
  error: boolean;
  errorMessage: string;
  showModal: boolean;
  private codigoAux: string;
  pedido:Pedido={};
  encuesta:ClienteInterface={};

  @ViewChild('modalPedido',{static:false}) modalRegistro: PedidosRegistroComponent;
  showModalRegistro: boolean;

  options: Object = {
    fieldSeparator: ';',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true,
    headers: ['Pedido', 'Estado', 'Precio', 'Cliente', 'Mozo', 'Mesa', 'Sector'],
    showTitle: true,
    title: 'Lista de Pedidos',
    useBom: true,
    removeNewLines: true,
    keys: ['descripcion', 'estado', 'importe', 'cliente', 'nombreMozo', 'idMesa', 'sector']
  };
 
  data: Object[];

  constructor(private pedidoService: PedidoService, private fb: FormBuilder) {
    this.refrescarEvent = new EventEmitter<void>();
    this.form = this.fb.group({
      tiempoEstimado: [0, Validators.required]

    });
    this.cargarLista();
  }

  ngOnInit() {
  }


  public cargarLista() {


    if(this.esCliente){

      this.data=this.listaPedidos;

      if(this.listaPedidos.length>0)
      {
         var i=0;
         this.listaPedidos.forEach(pedido=>{
          if(i=1){
            i=i+1;
               this.encuesta.cliente= pedido.cliente;
               this.encuesta.mozo=pedido.nombreMozo;
               this.encuesta.mesa=pedido.idMesa;
               localStorage.setItem("encuestaCli",JSON.stringify(this.encuesta));
          }

         });
      }

    }else{
      this.pedidoService.ListarTodos().subscribe( response => {
        this.listaPedidos = response;
        this.data=this.listaPedidos;
      
        //guardo datos del cliente y modo en sesion
        if(this.esCliente && this.listaPedidos.length>0)
        {
           var i=0;
           this.listaPedidos.forEach(pedido=>{
            if(i=1){
              i=i+1;
                 this.encuesta.cliente= pedido.cliente;
                 this.encuesta.mozo=pedido.nombreMozo;
                 this.encuesta.mesa=pedido.idMesa;
                 localStorage.setItem("encuestaCli",JSON.stringify(this.encuesta));
            }
  
           });
        }
  
      },
      error => {
        console.error(error);
      });
    }



  }


  showRegistroModal() {
    this.showModalRegistro = true;
  }

  generarNombreExcell():string{
    const nombre = 'ListaPedidos ' + new Date().toDateString();
    return nombre;
  }
  generarNombreCsv(): string {
    const nombre = 'ListaPedidos ' + new Date().toDateString();
    return nombre;
  }

  calcularTotal(): Number {
    let total: Number = 0;
    if (this.listaPedidos) {
      total = +this.listaPedidos.map( pedido => {
        return pedido.importe;
      }).reduce( (importeAnterior, importeActual) => {
        return importeAnterior + importeActual;
      });
    }

    return total;
  }

  refrescar() {
    this.refrescarEvent.emit();
  }

  marcarParaServir(pedido) {
     this.pedidoService.MarcarListoParaServir(pedido).then( () => {
      this.refrescar();
    }); 
  }

  tomarPedido() {
    this.errorMessage = '';
    this.error = false;
    if (this.form.valid) {
      const tiempoEstimado = this.form.get('tiempoEstimado').value;

        this.pedidoService.TomarPedido(this.pedido, tiempoEstimado).then(
          response => {
            console.log(response);
            this.refrescar();
            this.showModal = false;
          },
          error => {
            console.log(error);
          }
        ); 
    } else {
      this.errorMessage = 'Debe completar los campos correctamente.';
      this.error = true;
    }
  }

  servirPedido(pedido:Pedido) {
     this.pedidoService.Servir(pedido).then( () => {  
      this.refrescar();
    }); 
  }

  cancelarPedido(pedido:Pedido) {
    this.pedidoService.Cancelar(pedido).then( () => {
      this.refrescar();
    });
  }

  ClickTomarPedido(pedido:Pedido) {
    this.pedido = pedido;
    this.showModal = true;
  }

  public generarPDF()  
  {  
    var data = document.getElementById('tablaPDF');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 208;   
      var pageHeight = 295;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new PDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('PDFempleados.pdf'); // Generated PDF   
    });  
  }  

}
