import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { PedidoService } from '../../servicios/pedido.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/servicios/auth.service';
import { parse } from 'querystring';
import {EmpleadoService}from 'src/app/servicios/empleado.service';

@Component({
  selector: 'app-bienvenida',
  templateUrl: './bienvenida.component.html',
  styleUrls: ['./bienvenida.component.scss']
})
export class BienvenidaComponent implements OnInit {

  public mesaGroup: FormGroup;
  public respuestaInvalida: boolean;

  public isCliente:any=null;
  public userUid:string=null;

  @ViewChild('btnClose',{static:false}) btnClose: ElementRef;

  constructor(private fb: FormBuilder,private authService :AuthService, private pedidoService: PedidoService, private router: Router,private empService:EmpleadoService) {
    this.mesaGroup = this.fb.group({
      mesa: ['', [Validators.required, Validators.pattern('^MESA\\d{3}')]]
    });
    this.respuestaInvalida = false;
  }

  ngOnInit() {
    this.getCurrentUser();
  }

  logout() {
      localStorage.clear();
      this.authService.logout();
      this.router.navigate(['/Login']); 
    }

  getCurrentUser()
  {

    this.authService.isAuth().subscribe(user=>{
              
      this.empService.obtenerEmpleado(user.uid).subscribe(emp=>{

        if(emp.length!=0)
        {   
          this.isCliente=false;
          localStorage.setItem('Empleado',JSON.stringify(emp[0]))
        }else{
          this.isCliente=true;
          localStorage.setItem('Cliente',JSON.stringify(user))
        }
    

      })
      
    });    

    const data = localStorage.getItem('Empleado');
    
   
  }

  public ValidarMesa() {
     if (this.mesaGroup.get('mesa').valid) {
      const codigoMesa: string = this.mesaGroup.get('mesa').value;
      this.pedidoService.ListarPorMesa(codigoMesa).subscribe(
        response => {
          if (response.length === 0) {
            this.respuestaInvalida = true;
          } else {
            this.router.navigate(['Empleados/Clientes/', codigoMesa]);
            this.btnClose.nativeElement.click();
          }
        });
    } else {
      this.mesaGroup.get('mesa').markAsTouched();
    } 
  }

}
