import { MenuService } from './../../../servicios/menu.service';
import { FormBuilder, Validators } from '@angular/forms';
import { MesasService } from 'src/app/servicios/mesas.service';
import { Component, Input,OnInit, EventEmitter, Output, ViewChild ,ElementRef } from '@angular/core';
import { Registro } from '../../Common/Registro';
import { PedidoService } from 'src/app/servicios/pedido.service';
import { Mesa } from 'src/app/clases/Mesa';
import { Menu } from 'src/app/clases/Menu';
import { Pedido } from 'src/app/clases/Pedido';
import { Empleado } from 'src/app/clases/Empleado';

@Component({
  selector: 'app-pedidos-registro',
  templateUrl: './pedidos-registro.component.html',
  styleUrls: ['./pedidos-registro.component.scss']
})
export class PedidosRegistroComponent extends Registro implements OnInit {


  menu:Menu;
  mesa:Mesa;
  mesas: Mesa[];
  menuList: Menu[];
  @Input() showModalRegistro: boolean;
  @Output() closeModal: EventEmitter<void>;
  pedido:Pedido={};
  empleado:Empleado;


  constructor(private fb: FormBuilder, private mesasService: MesasService
    , private pedidoService: PedidoService, private menuService: MenuService) {
    super();
     this.resetForm(); 
     this.closeModal = new EventEmitter<void>();
  }

  ngOnInit() {
  }

  resetForm() {
    this.form = this.fb.group({
      cliente: ['', Validators.required],
      mesa: [0],
      menu: [0]
    });

    this.mesasService.Listar().subscribe(response => {
      this.mesas = response;
      if (this.mesas && this.mesa.estado=="Cerrrada") {
        this.form.get('mesa').setValue(this.mesas[0].codigo);
      }
    });

    this.menuService.Listar().subscribe(response => {
      this.menuList = response;
      if (this.menuList) {
        this.form.get('menu').setValue(this.menuList[0].id);
      }
    });
  }

  Submit() {
    this.errorMessage = '';
    this.error = false;
    this.success = false;
    if (this.form.valid) {
      this.getCurrentUser();
      
      this.pedido.cliente=this.form.get('cliente').value;
      this.pedido.idMesa=this.form.get('mesa').value;

      this.mesas.forEach(mesa=>{
          
        if(mesa.id=this.pedido.idMesa){
          this.mesa=mesa;
        }
      });

      this.pedido.idEmpleado=this.empleado.id;
      this.pedido.nombreMozo=this.empleado.nombre;

      //obtengo los datos del menu 
      this.menuList.forEach(menu=>{
        if(menu.id==this.form.get('menu').value){
          this.pedido.idMenu=menu.id;
          this.pedido.descripcion=menu.nombre;
          this.pedido.importe=menu.precio;
          this.pedido.sector=menu.sector;
        }
      });
      
      //obtengo los datos de la mesa 

      this.pedidoService.Registrar(this.pedido)
        .then(
          response => {

            if (response) {
              //actualizo la mesa
              this.mesasService.CambiarEstadoEsperando(this.mesa);
              //actualizo el movimiento del empleado
              this.pedidoService.SumarMovimientoEmpleado(this.empleado);
              this.success = true;
              this.resetForm();
              this.registradoCorrectamente.emit();
              this.cerrar();
            } else {
              this.error = true;
              this.errorMessage = "Error al registrar pedido";
            }
          }
        )
        .catch(
          error => {
            this.error = true;
            this.errorMessage = error['Mensaje'];
            console.error(error);
          }
        );
    } else {
      this.errorMessage = 'Debe completar los campos correctamente.';
      this.error = true;
    }
  }
  cargarModal() {
    this.showModalRegistro=true;
    //this.cargarForm();
  }
  
  cerrar() {
    this.closeModal.emit();
    this.form.reset();
  }

  getCurrentUser()
  {

    const data = localStorage.getItem('Empleado');
  
    if(data){
      this.empleado=JSON.parse(data);       
    }
  }
}
