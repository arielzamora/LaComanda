import { Pedido } from './../../clases/Pedido';
import { Component, OnInit,ViewChild } from '@angular/core';
import { PedidoService } from 'src/app/servicios/pedido.service';
import { PedidosMesaComponent } from '../clientes/pedidos-mesa/pedidos-mesa.component';

@Component({
  selector: 'app-pedidos-board',
  templateUrl: './pedidos-board.component.html',
  styleUrls: ['./pedidos-board.component.scss']
})
export class PedidosBoardComponent implements OnInit {

  @ViewChild(PedidosMesaComponent,{static:false})
  private listComponent: PedidosMesaComponent;

  constructor() {
  }

  ngOnInit() {
  }

  cargarLista() {
    this.listComponent.cargarLista();
  }



  
}
