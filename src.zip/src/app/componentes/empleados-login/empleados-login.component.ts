import { Component, OnInit,ElementRef,ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
import { AuthService } from 'src/app/servicios/auth.service';
import { Login } from 'src/app/clases/Login';
import { Registro } from './../Common/Registro';
import { Router } from '@angular/router';
import { ReCaptcha2Component } from 'ngx-captcha';

import {AngularFireStorage}from '@angular/fire/storage';
import {finalize}from 'rxjs/operators';
import {Observable} from 'rxjs/internal/Observable';
import {EmpleadoService}from 'src/app/servicios/empleado.service';

@Component({
  selector: 'app-empleados-login',
  templateUrl: './empleados-login.component.html',
  styleUrls: ['./empleados-login.component.scss']
})
export class EmpleadosLoginComponent extends Registro implements OnInit {

  public form: FormGroup;
  public error: boolean;
  public errorMessage: string;
  @ViewChild('captchaElem',{static:true}) captcha: ReCaptcha2Component;
  @ViewChild('inputEmail',{static:true}) inputEmail: ReCaptcha2Component;
  @ViewChild('inputPassword',{static:true}) inputPasword: ReCaptcha2Component;

  validation_messages = {
    'mail': [
      { type: 'required', message: 'Debe ingresar un email.' },
      { type: 'email', message: 'Debe ingresar un email válido.' }
    ],
    'password': [
      { type: 'required', message: 'Debe ingresar una contraseña.' }
    ]
  };

  public user:string ='';
  public pass:string ='';

  public isCliente:any=null;
  public userUid:string=null;

  constructor(private fb: FormBuilder, public authService:AuthService,private router:Router,private fireStore:AngularFireStorage,private empService:EmpleadoService){
    super();
   
   /*  this.form = this.fb.group({
      user: new FormControl('', Validators.compose([
        Validators.required,
        Validators.user
      ])),
      password: new FormControl('', Validators.required)
    }); */
   
   

 
  }

  ngOnInit() {
    this.form = this.fb.group({
      user: ['', Validators.required],
      pass: ['', Validators.required],
      recaptcha: ['', Validators.required]
    });
  }

  resolved(captchaResponse: string) {
    console.log(`Resolved captcha with response: ${captchaResponse}`);
  }

  CargarDefault(tipo: string) {

    let dataLogin: Login = null;
    switch (tipo) {
      case 'S':
        this.form.controls['user'].setValue('admin@admin.com');
        this.form.controls['pass'].setValue('123456');          
        break;
      case 'B':
          this.form.controls['user'].setValue('bartender@comanda.com');
          this.form.controls['pass'].setValue('123456');   
        break;
      case 'CE':
          this.form.controls['user'].setValue('cervecero@comanda.com');
          this.form.controls['pass'].setValue('123456');   
        break;
      case 'CO':
          this.form.controls['user'].setValue('cocinero@comanda.com');
          this.form.controls['pass'].setValue('123456');   
        break;
      case 'M':
          this.form.controls['user'].setValue('mozo@comanda.com');
          this.form.controls['pass'].setValue('123456');   
        break;
        case 'CLI':
          this.form.controls['user'].setValue('cliente@comanda.com');
          this.form.controls['pass'].setValue('123456');   
        break;
    }
  }

  public Submit(): void {
    this.errorMessage = '';
    this.error = false;
    let empleado;
    if (this.form.valid) {
      const dataLogin: Login = new Login(this.form.get('user').value,this.form.get('pass').value);
      this.authService.Loguear(dataLogin)
        .then(
          res => {      
                        
              //guardo el elmpeado
              this.router.navigate(["/Bienvenida"]);

          }
        )
        .catch(error => {
            this.error = true;
            //this.errorMessage = res['Mensaje'];
            if (error.code === 'auth/user-not-found') {
              //this.toastService.error('Usuario no encontrado.');
            this.errorMessage='Usuario no encontrado.';
            } else if (error.code === 'auth/wrong-password') {
              //this.toastService.error('Contraseña incorrecta.');
            this.errorMessage='Contraseña incorrecta.';
            } else {
              //this.toastService.error('Ocurrió un error, contáctese con el administrador.');
            this.errorMessage='Ocurrió un error, contáctese con el administrador.';
            }     
          }
        );
    } else {
      this.errorMessage = 'Debe completar los campos correctamente.';
      this.error = true;
    }
  }
 
 
  
  onLoginGoogle():void
  {
    this.authService.loginGoogleUser().then((res)=>{
      this.onLoginRedirect();
    }).catch(err=>console.log('err',err.Message));
   
  }

  onLoginFacebook():void
  {
    this.authService.loginFacebookUser().then((res)=>{
     this.onLoginRedirect();
    }).catch(err=>console.log('err',err.Message));
  }
  onLogout():void
  {
    this.authService.logoutUser();
  }

  onLoginRedirect():void{
    this.router.navigate(['/Bienvenida']);
  }



}
