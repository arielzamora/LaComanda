import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/servicios/auth.service';
import { UserInterface } from 'src/app/clases/User';
import { Empleado } from 'src/app/clases/Empleado';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.component.html',
  styleUrls: ['./perfil.component.scss']
})
export class PerfilComponent implements OnInit {

  constructor(private authService:AuthService) {}
  user:UserInterface={
    name:'',
    tipo:'',
    email:'',
    photoUrl:''
  };

  public providerId:string ='null';
  empleado:Empleado;

ngOnInit() {
  const data = localStorage.getItem('Empleado');  
  if(data){
      this.empleado=JSON.parse(data);
  this.authService.isAuth().subscribe(user=>{
     if(user){
       this.user.name=user.displayName;
       this.user.email=user.email;
       this.user.tipo=this.empleado.tipo;
       this.user.photoUrl=this.empleado.foto;
       this.providerId=user.providerData[0].providerId;
     }
    });
  }else{//es cliente
    const data = localStorage.getItem('Cliente');  
    this.authService.isAuth().subscribe(user=>{
      if(user){
        this.user.name=user.displayName;
        this.user.email=user.email;
        this.user.tipo="Cliente";
        this.user.photoUrl=user.photoURL;
        this.providerId=user.providerData[0].providerId;
      }
     });
  }
}

}
