export enum BotonPedido {
    Cancelar,
    ParaServir,
    Servir,
    Tomar
}
