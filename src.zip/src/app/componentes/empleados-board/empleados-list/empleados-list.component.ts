import { CaptchaComponent } from './../../Common/captcha/captcha.component';
import { EmpleadosModifyComponent } from './../empleados-modify/empleados-modify.component';
import { Angular2CsvComponent} from 'angular2-csv';
import { Empleado } from './../../../clases/Empleado';
import { EmpleadoService } from './../../../servicios/empleado.service';
import { Component, OnInit, ViewChild} from '@angular/core';
import { getLocaleDateTimeFormat } from '@angular/common';
import { EmpleadosRegistroComponent } from '../empleados-registro/empleados-registro.component';
import { ok } from 'assert';
import * as PDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-empleados-list',
  templateUrl: './empleados-list.component.html',
  styleUrls: ['./empleados-list.component.scss']
})
export class EmpleadosListComponent implements OnInit {
  @ViewChild('modalModify',{static:false}) modalModify: EmpleadosModifyComponent;
  @ViewChild('modalRegistro',{static:false}) modalRegistro: EmpleadosRegistroComponent;
  @ViewChild('captcha',{static:false}) captcha: CaptchaComponent;
  public listaEmpleados: Empleado[];
  options: Object = {
    fieldSeparator: ';',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true,
    headers: ['Nombre', 'Tipo', 'Mail', 'Último Login', 'Estado', 'N° de Operaciones'],
    showTitle: true,
    title: 'Lista de Empleados',
    useBom: true,
    removeNewLines: true,
    keys: ['nombre', 'tipo', 'mail', 'ultimoLogin', 'estado', 'cantidad_operaciones']
  };
  data: Object[];

  modalUser: string;
  modalId: number;
  modalType: string;
  modalName: string;
  showModal: boolean;
  showModalRegistro: boolean;

  constructor(private empleadoService: EmpleadoService) {
    this.cargarLista();
  }

  ngOnInit() {
  }

  public cargarLista() {
    this.empleadoService.Listar().subscribe(
      data => {
        this.listaEmpleados = data;
        this.data = this.listaEmpleados;
      },
      error => {
        console.log(error);
      }
    );
  }

  showModifyModal(empleado: Empleado) {
    this.modalModify.cargarModal(empleado);
    this.showModal = true;
  }

  showRegistroModal() {
    this.modalRegistro.cargarModal();
    this.showModalRegistro = true;
  }

  generarNombreCsv(): string {
    const nombre = 'ListaEmpleados ' + new Date().toDateString();
    return nombre;
  }

  mostrarCaptcha() {
    this.captcha.cargarCaptcha();
  }

  darDeBaja(empleado:Empleado) {
    this.empleadoService.Baja(empleado).
    then( response => {
      this.cargarLista();
    },
    error => {
      console.log(error);
    });
  }

  suspender(empleado:Empleado) {
    this.empleadoService.Suspender(empleado).then( response => {
      this.cargarLista();
    },
    error => {
      console.log(error);
    });
  }

  activar(empleado:Empleado) {
    this.empleadoService.Activar(empleado).then( response => {
      this.cargarLista();
    },
    error => {
      console.log(error);
    });
  }

  public generarPDF()  
  {  
    var data = document.getElementById('tablaPDF');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 208;   
      var pageHeight = 295;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new PDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('PDFPedidos.pdf'); // Generated PDF   
    });  
  }  

}
