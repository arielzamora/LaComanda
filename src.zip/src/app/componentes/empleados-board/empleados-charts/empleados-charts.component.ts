import { EmpleadoService } from './../../../servicios/empleado.service';
import { Component, OnInit } from '@angular/core';
import { OperacionesPorSector } from 'src/app/clases/OperacionesPorSector';
import { AngularFirestore } from '@angular/fire/firestore';
import { Empleado } from 'src/app/clases/Empleado';

@Component({
  selector: 'app-empleados-charts',
  templateUrl: './empleados-charts.component.html',
  styleUrls: ['./empleados-charts.component.scss']
})
export class EmpleadosChartsComponent implements OnInit {
  chartOptions: Object; // required
  operacionesPorSector: OperacionesPorSector[];
  empleados: Array<Empleado>;
  public operacionesBar:number=0;
  public operacionesCocina:number=0;
  public operacionesMozo:number=0;
  public operacionesSocio:number=0;
  public operacionesCerveza:number=0;


  constructor(private fireStore:AngularFirestore, private empleadoService: EmpleadoService) {

    this.empleados = new Array<Empleado>();
   
  }

  ngOnInit() {
    let empleados = this.fireStore.collection("Empleado").valueChanges();
    const datos: { name: String, y: number}[] = new Array();
    this.operacionesPorSector

    empleados.forEach(emp=>
      {
        emp.forEach(item=>
          {
            this.empleados.push(item);                   
          });
          this.empleados.forEach(element => {
            switch (element.tipo) {
              case 'Bartender':
                   this.operacionesBar=this.operacionesBar+element.cantidad_operaciones
              break;
              case 'Cocinero':
                   this.operacionesCocina=this.operacionesCocina+element.cantidad_operaciones;
              break;
              case 'Mozo':
                  this.operacionesMozo=this.operacionesMozo+element.cantidad_operaciones;
              break;
              case 'Cervecero':
                  this.operacionesCerveza=this.operacionesCerveza+element.cantidad_operaciones;
              break;
              case 'Socio':
                  this.operacionesSocio=this.operacionesSocio+element.cantidad_operaciones;
              break;
            }    
                       
          });
          datos.push({
            name:"Sector Bar",
            y: this.operacionesBar
          });
          datos.push({
            name:"Sector Cocina",
            y: this.operacionesCocina
          });
          datos.push({
            name:"Sector Mozo",
            y:this.operacionesMozo
          });
          datos.push({
            name:"Cervezas",
            y: this.operacionesCerveza
          });
          datos.push({
            name:"Operaciones Socio",
            y: this.operacionesSocio
          });

          this.chartOptions = {
            chart: {
              plotBackgroundColor: null,
              plotBorderWidth: null,
              plotShadow: false,
              type: 'pie',
              style: {
                textAlign: 'center'
              }
            },
            title: {
              text: 'Porcentaje de Operaciones por Sector'
            },
            tooltip: {
              pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
              pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                  connectorColor: 'silver'
                }
              }
            },
            series: [{
              name: 'Operaciones por Sector',
              data: datos
            }]
          };
    
      });
    
    
   
  }
}
