import { Registro } from './../../Common/Registro';
import { EmpleadoService } from './../../../servicios/empleado.service';
import { Component, Input,OnInit, EventEmitter, Output, ViewChild ,ElementRef} from '@angular/core';
import { FormBuilder, FormGroup, FormControl,  Validators } from '@angular/forms';
import { ReCaptcha2Component } from 'ngx-captcha';

//import { Component, OnInit,ElementRef,ViewChild } from '@angular/core';
import {Router}from '@angular/router';
import { AuthService }from '../../../servicios/auth.service';
import {AngularFireStorage}from '@angular/fire/storage';
import {finalize}from 'rxjs/operators';
import {Observable} from 'rxjs/internal/Observable';
import { Empleado } from 'src/app/clases/Empleado';




@Component({
  selector: 'app-empleados-registro',
  templateUrl: './empleados-registro.component.html',
  styleUrls: ['./empleados-registro.component.scss']
})
export class EmpleadosRegistroComponent extends Registro  implements OnInit  {
    
    @ViewChild('imageUser',{static:true}) inputImageUser:ElementRef;//hidden
    @ViewChild('imageInput',{static:true}) inputImage:ElementRef;//imput
    @ViewChild('captchaElem',{static:true}) captcha: ReCaptcha2Component;
    @Input() showModalRegistro: boolean;
    @Output() closeModal: EventEmitter<void>;
    @Output() registradoCorrectamente: EventEmitter<void>;
  
    uploadPercent: Observable<number>;
    urlImage:Observable<string>;
    empleado:Empleado={};

    submitted = false;
  
    get f() { return this.form.controls; }

  constructor(private fb: FormBuilder, private empleadoService: EmpleadoService,public afAuth:AuthService,private router:Router,private fireStore:AngularFireStorage) {
       super();
    this.closeModal = new EventEmitter<void>();
    
  }

  ngOnInit() {
 
    this.form = this.fb.group({
      usuario: ['', Validators.required],
      password: ['', Validators.required],
      nombre: ['', Validators.required],
      tipo: ['',Validators.required],
      recaptcha: ['', Validators.required]
    });

  }
   

  
  public registrarEmpleado(emp:Empleado): void {
      this.empleadoService.Registrar(emp)
        .then(
          response => {
            console.log(response);
            if (response) {
              //this.success = true;
              this.form.reset();
              this.form.get('tipo').setValue('Socio');
              this.captcha.reloadCaptcha();
              this.captcha.resetCaptcha();
              this.inputImage.nativeElement.value = null;
              this.inputImageUser.nativeElement.value = null;
              this.registradoCorrectamente.emit();
            } else {
              this.error = true;
              this.errorMessage = 'error al insertar un empleado';
            }
          }
        )
        .catch(
          error => {
            this.error = true;
            this.errorMessage = 'error al insertar empleado';
            console.log(error);
          }
        );
  }

  Submit()
  {

    this.errorMessage = '';
    this.error = false;
    this.success = false;
    this.submitted=true;
    
   // this.success = false;
    if (this.form.valid) {
     
      this.empleado.usuario = this.form.get('usuario').value;
      this.empleado.password =this.form.get('password').value;
      this.empleado.nombre =this.form.get('nombre').value;
      this.empleado.tipo = this.form.get('tipo').value;

    //registro el usuario   
    this.afAuth.registerUser(this.empleado.usuario,this.empleado.password)//falta el nombre y el tipo
    .then((res)=>{
      
       this.afAuth.isAuth().subscribe(user=>{
        if(user){
          user.updateProfile({
            displayName:this.empleado.nombre,
            photoURL:this.inputImageUser.nativeElement.value
          }).then(()=>{

            //actualizamos el empleado
            this.empleado.idUser=user.uid;
            this.empleado.cantidad_operaciones=0;
            this.empleado.estado="A";
            this.empleado.foto=this.inputImageUser.nativeElement.value;

            this.registrarEmpleado(this.empleado);

            this.cerrar();
            
          }).catch((error)=>console.log('error',error));
        }
       });    
    }).catch(err=> console.log('err',err.message))
    }else{
      return;
    }
  }


  onUpload(e)
  {
    //creamos un id aleatorio para poder asociarlo a la imagen
    const id = Math.random().toString(36).substring(2);
    const file=e.target.files[0];
    const filePath = 'uploads/profile_'+id;
    const ref=this.fireStore.ref(filePath);
    const task=this.fireStore.upload(filePath,file)
    this.uploadPercent=task.percentageChanges();//recuperamos el porcentaje de carga del archivo
    task.snapshotChanges().pipe(finalize(()=>this.urlImage=ref.getDownloadURL())).subscribe();
  }

  cargarModal() {
    //this.cargarForm();
  }

  cargarForm(){
    this.form = this.fb.group({
    });
  }


  onLogout():void
  {
    this.afAuth.logoutUser();
  }

  onLoginRedirect():void{
    this.router.navigate(['admin/list-books']);
  }

  cerrar() {
    this.closeModal.emit();
    this.form.reset();
  }

}
