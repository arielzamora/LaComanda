import { Component, OnInit, EventEmitter, Output, ViewChild,Input } from '@angular/core';
import { ReCaptcha2Component } from 'ngx-captcha';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import { Registro } from '../../Common/Registro';
import { MesasService } from 'src/app/servicios/mesas.service';
import { Mesa } from 'src/app/clases/Mesa';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-mesa-registro',
  templateUrl: './mesa-registro.component.html',
  styleUrls: ['./mesa-registro.component.scss']
})
export class MesaRegistroComponent extends Registro implements OnInit {

  file;
  mesa:Mesa={};
  @Input() showModalRegistro: boolean;
  @Output() closeModal: EventEmitter<void>;

  submitted = false;
  get f() { return this.form.controls; }

  constructor(private fb: FormBuilder, private mesasService: MesasService) {
    super();
    this.closeModal = new EventEmitter<void>();
   
  
  }

  ngOnInit() {
    this.form = this.fb.group({
      codigo: ['', Validators.required],
      foto: [''],
      recaptcha: ['', Validators.required]
    });
  }

  onFileChange(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.file = {
          filename: file.name,
          filetype: file.type,
          value: reader.result.toString().split(',')[1]
        };
      };
    }
  }

  ValidarFoto(foto): Boolean {
    if (foto) {
      return (foto.filetype === 'image/jpeg'
      || foto.filetype === 'image/png'
      || foto.filetype === 'image/gif');
    } else {
      return true;
    }
  }

  Submit() {
    this.errorMessage = '';
    this.error = false;
    this.success = false;
    this.submitted=true;
    const fotoValida = this.ValidarFoto(this.file);
    if (this.form.valid && fotoValida) {

      this.mesa.codigo = this.form.get('codigo').value;
      this.mesa.estado = 'Cerrada';
      this.mesa.tipoFoto = this.file.filename;
      this.mesa.nombreFoto = this.file.filetype;
      this.mesa.foto = this.file.value;

      this.mesasService.Registrar(this.mesa)
        .then(
          response => {
            console.log(response);
            if (response) {
              this.success = true;
              this.form.reset();
              this.captcha.reloadCaptcha();
              this.captcha.resetCaptcha();
              this.registradoCorrectamente.emit();
              this.cerrar();
            } else {
              this.error = true;
              this.errorMessage = "error al registrar mesa";
            }
          }
        )
        .catch(
          error => {
            this.error = true;
            this.errorMessage = "error al registrar mesa";
            console.log(error);
          }
        );
    } else if (!fotoValida) {
      this.errorMessage = 'El archivo debe ser una imagen.';
      this.error = true;
    } else {
      this.errorMessage = 'Debe completar los campos correctamente.';
      this.error = true;
    }
  }

  cargarModal() {
    //this.cargarForm();
    //this.form.reset();
  }

  cargarForm(){
    this.form = this.fb.group({
      codigo: ['', Validators.required],
      foto: [''],
      recaptcha: ['', Validators.required]
    });
  }

  cerrar() {
    this.closeModal.emit();
    this.form.reset();
  }
}
