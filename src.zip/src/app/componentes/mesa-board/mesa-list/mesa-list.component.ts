import { Mesa } from './../../../clases/Mesa';
import { MesasService } from 'src/app/servicios/mesas.service';
import { Component, OnInit,ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MesaRegistroComponent } from '../mesa-registro/mesa-registro.component';
import * as PDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-mesa-list',
  templateUrl: './mesa-list.component.html',
  styleUrls: ['./mesa-list.component.scss']
})
export class MesaListComponent implements OnInit {
  mesasList: Mesa[];
  foto;
  @ViewChild('modalRegistro',{static:false}) modalRegistro: MesaRegistroComponent;
  modalUser: string;
  modalId: number;
  modalType: string;
  modalName: string;
  showModal: boolean;
  showModalRegistro: boolean;

  constructor(private mesasService: MesasService, private domSanitizer: DomSanitizer) {
    this.cargarLista();
  }

  ngOnInit() {
  }

  cargarLista() {
    this.mesasService.Listar().subscribe( response => {
      this.mesasList = response;
    });
  }
  
  showRegistroMesa() {
    //this.modalRegistro.cargarModal();
    this.showModalRegistro = true;
  }

  cambiarEstado(estado:number,mesa:Mesa) {
    switch (estado) {
      case 1:
        this.mesasService.CambiarEstadoEsperando(mesa).then( () => {
          this.cargarLista();
        });
        break;
      case 2:
        this.mesasService.CambiarEstadoComiendo(mesa).then( () => {
          this.cargarLista();
        });
        break;
      case 3:
        this.mesasService.CambiarEstadoPagando(mesa).then( () => {
          this.cargarLista();
        });
        break;
      case 4:
        this.mesasService.CambiarEstadoCerrada(mesa).then( () => {
          this.cargarLista();
        });
        break;
    }
    this.cargarLista();
  }

  eliminar(mesa:Mesa) {
    this.mesasService.Eliminar(mesa).then( () => {
      this.cargarLista();
    });
  }

  cobrar(mesa:Mesa) {
    this.mesasService.Cobrar(mesa).then( () => {
      this.mesasService.CambiarEstadoCerrada(mesa).then( () => {
        this.cargarLista();
      });
    });
  }

  public generarPDF()  
  {  
    var data = document.getElementById('tablaPDF');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 208;   
      var pageHeight = 295;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new PDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('PDFpedidos.pdf'); // Generated PDF   
    });  
  }  

}
