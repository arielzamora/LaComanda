import { JwtHelperService } from '@auth0/angular-jwt';
import { Directive, ElementRef, Renderer, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { User } from 'src/app/clases/User';
import { Empleado } from 'src/app/clases/Empleado';
import {EmpleadoService}from 'src/app/servicios/empleado.service';
import { AuthService } from 'src/app/servicios/auth.service';

@Directive({
  selector: '[appValidarRoles]'
})
export class ValidarRolesDirective implements OnInit {

  private rolesAdmitidos: string[];
  user: User;
  empleado:Empleado;
  public isCliente:any=null;
  public userUid:string=null;

  @Input() set appValidarRoles(value: string[]) {
    this.rolesAdmitidos = value;
  }

  constructor(private element: ElementRef,private templateRef: TemplateRef<any>,private viewContainer: ViewContainerRef) {
  }

  ngOnInit() {
    if (this.CheckRoles()) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }

  private CheckRoles(): Boolean {


    let retorno: Boolean = false;

    const data = localStorage.getItem('Empleado');

    if(data)
    {
      this.empleado=JSON.parse(data);//el empleado logueado

      if (this.rolesAdmitidos && data) {
        const tipoUsuario = this.empleado.tipo;
        this.rolesAdmitidos.forEach(element => {
          if (tipoUsuario === element) {
            retorno = true;
          }
        });
      }
    }else{//el cliente logueado
      if (this.rolesAdmitidos) {
        const tipoUsuario = "Cliente";
        this.rolesAdmitidos.forEach(element => {
          if (tipoUsuario === element) {
            retorno = true;
          }
        });
      }
    }



    return retorno;
  }

  
}
