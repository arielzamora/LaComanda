import { BotonPedido } from './../componentes/Common/botonPedido.enum';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Pedido } from './../clases/Pedido';
import { Directive, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Empleado } from 'src/app/clases/Empleado';

@Directive({
  selector: '[appAccionPedido]'
})
export class AccionPedidoDirective implements OnInit {
  pedido: Pedido;
  empleado:Empleado;
  @Input() set appAccionPedido(value: Pedido) {
    this.pedido = value;
  }

  boton: BotonPedido;
  @Input() set appAccionPedidoBoton(value: BotonPedido) {
    this.boton = value;
  }

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private jwt: JwtHelperService) {
  }

  ngOnInit() {

    const data = localStorage.getItem('Empleado');    

    let renderizar = false;

    if (data) {

      this.empleado=JSON.parse(data);//el empleado logueado
      
      const tipoUsuario = this.empleado.tipo;

      if (tipoUsuario !== 'Mozo') {
        switch (this.pedido.estado) {
          case 'En Preparacion':
            if (this.boton === BotonPedido.ParaServir) {
              renderizar = true;
            }
            break;
          case 'Pendiente':
            if (this.boton === BotonPedido.Tomar) {
              renderizar = true;
            }
            break;
        }
      }
      if (tipoUsuario === 'Mozo' || tipoUsuario === 'Socio') {
        switch (this.pedido.estado) {
          case 'Listo para Servir':
            if (this.boton === BotonPedido.Servir) {
              renderizar = true;
            }
          // tslint:disable-next-line:no-switch-case-fall-through
          case 'En Preparacion':
          case 'Pendiente':
            if (this.boton === BotonPedido.Cancelar) {
              renderizar = true;
            }
            break;
        }
      }

      if (renderizar) {
        this.viewContainer.createEmbeddedView(this.templateRef);
      }

    }



  }
}
