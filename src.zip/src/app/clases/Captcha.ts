export class Captcha {
    key: string;
    foto: string;
    estado: string;
}
