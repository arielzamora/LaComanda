export interface ClienteInterface
{
  cliente?:string;
  mozo?:string;
  mesa?:string;  
}

export class Cliente {
    public uid?: string;
    public displayName?: string;
    public tipo?: string;
    public email?: string;

}