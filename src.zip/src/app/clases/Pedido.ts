import { Time } from '@angular/common';

export class Pedido {
    public id?:string;
    public codigo?: string;
    public estado?: string;
    public idMesa?: string;
    public descripcion?: string;
    public idMenu?: string;
    public sector?: string;
    public cliente?: string;
    public nombreMozo?: string;
    public idEmpleado?: string;
    public idEncargado?: string;
    public horaInicial?: any;
    public horaEstimada?: any;
    public horaFinal?: any;
    public fecha?: any;
    public importe?: number;

    constructor()
    {
        
    }
}

