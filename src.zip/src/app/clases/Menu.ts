export class Menu {
    id: string;
    precio: number;
    nombre: string;
    sector: string;
}
