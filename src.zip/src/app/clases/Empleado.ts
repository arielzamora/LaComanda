import { Timestamp } from 'rxjs/internal/operators/timestamp';

export class Empleado {
    public id?: string;
    public idUser?: string;
    public nombre?: string;
    public tipo?: string;
    public usuario?: string;
    public password?:string;
    public fechaRegistro?:any;
    public foto?:any;
    public ultimoLogin?: any;
    public estado?: string;
    public cantidad_operaciones?: number;

    constructor( id: string,nombre: string, tipo: string,usuario: string,password:string,fechaRegistro: number,ultimoLogin: number,
        estado: string) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.usuario = usuario;
        this.password=password;
        this.fechaRegistro=fechaRegistro
        this.ultimoLogin=ultimoLogin;
        this.estado=estado;

        

    }

}
