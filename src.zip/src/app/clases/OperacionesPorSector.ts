export class OperacionesPorSector {
    public cantidad_operaciones: number;
    public sector: string;
}
