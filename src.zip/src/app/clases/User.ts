export interface Roles
{
  socio?:boolean;
  cervecero?:boolean;
  cocinero?:boolean;
  mozo?:boolean;
  cliente?:boolean;
  
}

export interface UserInterface {
    id?:string;
    name?:string;
    email?:string;
    password?:string;
    photoUrl?:string;
    tipo?:string;
    roles?:Roles;
}

export class User {
    usuario?:string;
    tipo?:string;
    id?:string;
    nombre?:string;
    foto?:string;

    constructor(usuario: string, tipo: string, id: string, nombre: string,foto:string) {
        this.usuario = usuario;
        this.tipo = tipo;
        this.id = id;
        this.nombre = nombre;
        this.foto=foto;
    }
}
